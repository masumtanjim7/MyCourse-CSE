package com.company;

public interface CollegueInterface {
    void receiveMessage(String message);
}
