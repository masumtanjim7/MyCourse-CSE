package com.company;

public interface MediatorInterface {
    void sendMessage(String message, CollegueInterface user);
}
